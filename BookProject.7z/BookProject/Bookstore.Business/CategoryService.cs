﻿using AutoMapper;
using Bookstore.Business.DataTransferObjects;
using Bookstore.Business.Extensions;
using BookStore.DataAccess.Repos;
using BookStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookstore.Business
{
    public class CategoryService : ICategoryService
    {

        private ICategoryRepo categoryRepo;
        private IMapper mapper;

        public CategoryService(ICategoryRepo categoryRepo, IMapper mapper)
        {
            this.categoryRepo = categoryRepo;
            this.mapper = mapper;
        }


        public int AddGCategory(AddNewCategoryRequest request)
        {
            var newCategory = request.ConvertToCategory(mapper);
            categoryRepo.Add(newCategory);
            return newCategory.Id;
        }

        public void DeleteCategory(int id)
        {
            categoryRepo.Delete(id);
        }

        public IList<GetAllCategoriesResponse> GetAllGCategories()
        {
            var dtoCategoryList = categoryRepo.GetAll().ToList();
            var result = dtoCategoryList.ConvertToCategoryListResponse(mapper);
            return result;
        }

        public GetAllCategoriesResponse GetCategoriesById(int id)
        {
            Category category = categoryRepo.GetById( id);
            return category.ConvertFromEntity(mapper);

        }

       

        public int UpdateCategory(EditCategoryRequest request)
        {
            var category = request.ConvertToEntity(mapper);
            int id = categoryRepo.Update(category).Id;
            return id;
        }

       
    }
}
