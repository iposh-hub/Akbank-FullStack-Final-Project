﻿using Bookstore.Business.DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookstore.Business
{
    public interface IPublisherService
    {
        IList<GetAllPublishersResponse> GetAllPublishers();
        //eklenen son varlığın id'si:
        int AddPublisher(AddNewPublisherRequest request);
        GetAllPublishersResponse GetPublishersById(int id);
        int UpdatePublisher(EditPublisherRequest request);
        void DeletePublisher(int id);

    }

}
