﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookstore.Business.DataTransferObjects
{
    public class AddNewPublisherRequest
    {
        [Required(ErrorMessage = "Tür adı boş geçilemez")]
        public string Name { get; set; }
    }
}
