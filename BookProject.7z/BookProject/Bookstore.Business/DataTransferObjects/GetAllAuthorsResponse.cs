﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookstore.Business.DataTransferObjects
{
    public class GetAllAuthorsResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
