﻿using Bookstore.Business.DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookstore.Business
{
    public interface IAuthorService
    {
        IList<GetAllAuthorsResponse> GetAllAuthors();
        //eklenen son varlığın id'si:
        int AddAuthor(AddNewAuthorRequest request);
        GetAllAuthorsResponse GetAuthorsById(int id);
        int UpdateAuthor(EditAuthorRequest request);
        void DeleteAuthor(int id);
        IList<EditBooksRequest> GetRegisteredBooks();
    }
}
