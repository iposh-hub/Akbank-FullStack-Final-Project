﻿using AutoMapper;
using Bookstore.Business.DataTransferObjects;
using Bookstore.Business.Extensions;
using BookStore.DataAccess.Repos;
using BookStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookstore.Business
{
    public class BookService : IBookService
    {

        private IBookRepo bookRepo;
        private IMapper mapper;

        public BookService(IBookRepo bookRepo, IMapper mapper)
        {
            this.bookRepo = bookRepo;
            this.mapper = mapper;
        }


        public int AddBook(AddNewBookRequest request)
        {
            var newBook = request.ConvertToBook(mapper);
            bookRepo.Add(newBook);
            return newBook.Id;
        }

        public void DeleteBook(int id)
        {
            bookRepo.Delete(id);
        }

        public IList<EditBooksRequest> GetAllBooks()
        {
            var dtoBookList = bookRepo.GetAll().ToList();
            var result = dtoBookList.ConvertToBookListResponse(mapper);
            return result;
        }

       

        public EditBooksRequest GetById(int id)
        {
            var book = bookRepo.GetById(id);
            return book.ConvertFromEntity(mapper);
        }

        

        public int UpdateBook(EditBooksRequest request)
        {
            var book = request.ConvertToEntity(mapper);
            int id = bookRepo.Update(book).Id;
            return id;
        }

        public Book GetBookByCriteria (string term) 
        {
            return bookRepo.GetWithCriteria(b => b.Name == term | b.Author.Name==term).FirstOrDefault();
        }

        
    }
}
