﻿using AutoMapper;
using Bookstore.Business.DataTransferObjects;
using Bookstore.Business.Extensions;
using BookStore.DataAccess.Repos;
using BookStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookstore.Business
{
    public class AuthorService : IAuthorService
    {

        private IAuthorRepo authorRepo;
        private IMapper mapper;

        public AuthorService(IAuthorRepo authorRepo, IMapper mapper)
        {
            this.authorRepo = authorRepo;
            this.mapper = mapper;
        }


        public int AddAuthor(AddNewAuthorRequest request)
        {
            var newAuthor = request.ConvertToAuthor(mapper);
            authorRepo.Add(newAuthor);
            return newAuthor.Id;
        }

        public void DeleteAuthor(int id)
        {
            authorRepo.Delete(id);
        }

        public IList<GetAllAuthorsResponse> GetAllAuthors()
        {
            var dtoAuthorList = authorRepo.GetAll().ToList();
            var result = dtoAuthorList.ConvertToAuthorListResponse(mapper);
            return result;
        }

        public GetAllAuthorsResponse GetAuthorsById(int id)
        {
            Author author = authorRepo.GetById(id);
            return author.ConvertFromEntity(mapper);
        }

        public IList<EditBooksRequest> GetRegisteredBooks(int authorId)
        {
            throw new NotImplementedException();
        }

        public int UpdateAuthor(EditAuthorRequest request)
        {
            var author = request.ConvertToEntity(mapper);
            int id = authorRepo.Update(author).Id;
            return id;
        }
    }
}
