﻿using AutoMapper;
using Bookstore.Business.DataTransferObjects;
using BookStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookstore.Business.Mapper
{
   
    
        public class MappingProfile : Profile
        {
            public MappingProfile()
            {
                CreateMap<Category, GetAllCategoriesResponse>().ReverseMap();
                CreateMap<Category, AddNewCategoryRequest>().ReverseMap();
                CreateMap<Category, EditCategoryRequest>().ReverseMap();

            }
        }
    
}
