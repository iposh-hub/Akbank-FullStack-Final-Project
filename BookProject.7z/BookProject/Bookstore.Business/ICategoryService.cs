﻿using Bookstore.Business.DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookstore.Business
{
    public interface ICategoryService
    {
        IList<GetAllCategoriesResponse> GetAllGCategories();
        //eklenen son varlığın id'si:
        int AddGCategory(AddNewCategoryRequest request);
        GetAllCategoriesResponse GetCategoriesById(int id);
        int UpdateCategory(EditCategoryRequest request);
        void DeleteCategory(int id);
        
        
    }
}
