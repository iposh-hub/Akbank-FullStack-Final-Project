﻿using Bookstore.Business.DataTransferObjects;
using BookStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookstore.Business
{
    public interface IBookService
    {
        IList<EditBooksRequest> GetAllBooks();
        //eklenen son varlığın id'si:
        int AddBook(AddNewBookRequest request);
        EditBooksRequest GetById(int id);
        int UpdateBook(EditBooksRequest request);
        void DeleteBook(int id);
        Book GetBookByCriteria(string term);


    }
}
