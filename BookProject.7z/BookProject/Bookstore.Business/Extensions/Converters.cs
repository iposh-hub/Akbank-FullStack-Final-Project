﻿using AutoMapper;
using Bookstore.Business.DataTransferObjects;
using BookStore.Models;
using BookStore.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookstore.Business.Extensions
{
    public static class Converters
    {
        //Converters for Categories starts
        public static Category ConvertToCategory (this AddNewCategoryRequest request, IMapper mapper) 
        {
            return mapper.Map<Category>(request);
        }

        public static List<GetAllCategoriesResponse> ConvertToCategoryListResponse(this List<Category> categories, IMapper mapper)
        {
            return mapper.Map<List<GetAllCategoriesResponse>>(categories);
        }
        public static GetAllCategoriesResponse ConvertFromEntity(this Category category, IMapper mapper)
        {
            return mapper.Map<GetAllCategoriesResponse>(category);
        }

        public static Category ConvertToEntity(this EditCategoryRequest request, IMapper mapper)
        {
            return mapper.Map<Category>(request);
        }
        //Converters for Categories ends



        //Converters for Authors starts
        public static Author ConvertToAuthor(this AddNewAuthorRequest request, IMapper mapper)
        {
            return mapper.Map<Author>(request);
        }

        public static List<GetAllAuthorsResponse> ConvertToAuthorListResponse(this List<Author> authors, IMapper mapper)
        {
            return mapper.Map<List<GetAllAuthorsResponse>>(authors);
        }

        public static GetAllAuthorsResponse ConvertFromEntity(this Author author, IMapper mapper)
        {
            return mapper.Map<GetAllAuthorsResponse>(author);
        }

        public static Author ConvertToEntity(this EditAuthorRequest request, IMapper mapper)
        {
            return mapper.Map<Author>(request);
        }
        //Converters for Authors ends


        //Converters for Publishers starts
        public static Publisher ConvertToPublisher(this AddNewPublisherRequest request, IMapper mapper)
        {
            return mapper.Map<Publisher>(request);
        }
        public static List<GetAllPublishersResponse> ConvertToPublisherListResponse(this List<Publisher> publishers, IMapper mapper)
        {
            return mapper.Map<List<GetAllPublishersResponse>>(publishers);
        }

         public static GetAllPublishersResponse ConvertFromEntity(this Publisher publisher, IMapper mapper)
         {
            return mapper.Map<GetAllPublishersResponse>(publisher);
         }

        public static Publisher ConvertToEntity(this EditPublisherRequest request, IMapper mapper)
        {
            return mapper.Map<Publisher>(request);
        }

        //Converters for Publishers ends

        //Converters for Books starts

        public static Book ConvertToBook(this AddNewBookRequest request, IMapper mapper)
        {
            return mapper.Map<Book>(request);
        }

        public static List<EditBooksRequest> ConvertToBookListResponse(this List<Book> books, IMapper mapper)
        {
            return mapper.Map<List<EditBooksRequest>>(books);
        }

        public static EditBooksRequest ConvertFromEntity(this Book book, IMapper mapper)
        {
            return mapper.Map<EditBooksRequest>(book);
        }
         public static Book ConvertToEntity(this EditBooksRequest request, IMapper mapper)
         {
            return mapper.Map<Book>(request);
         }

         public static Book ConvertFromBookWithPublishers (this EditBooksRequest request, IMapper mapper ) 
         {

            return mapper.Map<Book>(request);
         }

        //Converters for Books ends


    }
}
