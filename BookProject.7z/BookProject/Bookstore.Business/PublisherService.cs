﻿using AutoMapper;
using Bookstore.Business.DataTransferObjects;
using Bookstore.Business.Extensions;
using Bookstore.Business.Mapper;
using BookStore.DataAccess.Repos;
using BookStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookstore.Business
{
    public class PublisherService : IPublisherService
    {

        private IPublisherRepo publisherRepo;
        private IMapper mapper;

        public PublisherService(IPublisherRepo publisherRepo, IMapper mapper)
        {
            this.publisherRepo = publisherRepo;
            this.mapper = mapper;
        }

        public int AddPublisher(AddNewPublisherRequest request)
        {
            var newPublisher = request.ConvertToPublisher(mapper);
            publisherRepo.Add(newPublisher);
            return newPublisher.Id;
        }

        public void DeletePublisher(int id)
        {
            publisherRepo.Delete(id);
        }

        public IList<GetAllPublishersResponse> GetAllPublishers()
        {
            var dtoPublisherList = publisherRepo.GetAll().ToList();
            var result = dtoPublisherList.ConvertToPublisherListResponse(mapper);
            return result;
        }

        public GetAllPublishersResponse GetPublishersById(int id)
        {
            Publisher publisher = publisherRepo.GetById(id);
            return publisher.ConvertFromEntity(mapper);
        }


        public int UpdatePublisher(EditPublisherRequest request)
        {
            var publisher = request.ConvertToEntity(mapper);
            int id = publisherRepo.Update(publisher).Id;
            return id;
        }

        
    }
}
