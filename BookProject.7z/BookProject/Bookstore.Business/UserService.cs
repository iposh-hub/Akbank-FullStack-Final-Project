﻿using BookStore.DataAccess.Repos;
using BookStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bookstore.Business
{
    public class UserService : IUser
    {

        private IUserRepo userRepository;

        public UserService(IUserRepo userRepo) 
        {
            this.userRepository = userRepo;
        }
        
        public User GetUser(string userName, string password)
        {
            return userRepository.GetWithCriteria(x => x.UserName == userName && x.Password == password).FirstOrDefault();


        }
    }
}
