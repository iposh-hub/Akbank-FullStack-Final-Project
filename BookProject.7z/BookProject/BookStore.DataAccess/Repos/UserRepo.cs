﻿using BookStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore.DataAccess.Repos
{
    public class UserRepo : IUserRepo
    {
        public User Add(User book)
        {
            throw new NotImplementedException();
        }

        public void Delete(int id)
        {
            throw new NotImplementedException();
        }


        private List<User> users = new List<User>
           {
               new User { Email="abc@xxx.com", Password="123", UserName="turkay", Role="Admin"},
               new User { Email="def@xxx.com", Password="987", UserName="mahmut", Role="Editor"},
               new User { Email = "zxc@xxx.com", Password = "666", UserName="irem", Role="User" },


           };


        public IList<User> GetAll()
        {
            throw new NotImplementedException();
        }

        public User GetById(int id)
        {
            throw new NotImplementedException();
        }

        public IList<User> GetWithCriteria(Func<User, bool> ctiteria)
        {
            throw new NotImplementedException();
        }

        public User Update(User entity)
        {
            throw new NotImplementedException();
        }
    }
}
