﻿using BookStore.DataAccess.data;
using BookStore.Models;
using BookStore.ViewModels;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore.DataAccess.Repos
{
    public class EFBookRepo:IBookRepo
    {


        private BookDbContext db;

        public EFBookRepo(BookDbContext bookDbContext)

        {

            db = bookDbContext;

        }

        public Book Add(BookVM book)
        {

            var _book = new Book()
            {
                Name = book.Name,
                AboutBook = book.AboutBook,
                Price = book.Price,
                Discount = book.Discount,
                DiscountedPrice = book.DiscountedPrice,
                PosterPath = book.PosterPath,
                CategoryId = book.CategoryId,
                AuthorId = book.AuthorId,
            };
            db.Books.Add(_book);
            db.SaveChanges();
            foreach (var id in book.PublisherIds)
            {
                var _book_publisher = new Book_Publisher()
                {
                    BookId = _book.Id,
                    PublisherId = id
                };

                db.Book_Publishers.Add(_book_publisher);
                db.SaveChanges();
            }
            return _book;
        }

        public Book Add(Book book)
        {
            throw new NotImplementedException();
        }

        public void Delete(int id)
        {

            var book = db.Books.FirstOrDefault(n => n.Id == id);
            if (book != null) 
            {
                db.Books.Remove(book);
                db.SaveChanges();
            }
         
        }

        public IList<Book> GetAll()
        {
            return db.Books.ToList();
        }


       

        public BookWithPublishers GetById(int id)
        {
            var bookwithPublishers = db.Books.Where(n => n.Id == id).Select(book => new BookWithPublishers()
            {
                Name = book.Name,
                AboutBook = book.AboutBook,
                Price = book.Price,
                Discount = book.Discount,
                DiscountedPrice = book.DiscountedPrice,
                PosterPath = book.PosterPath,
                AuthorName = book.Author.Name,
                CategorName = book.Category.Name,
                PublisherNames = db.Book_Publishers.Select(n => n.Publisher.Name).ToList()

            }).FirstOrDefault();
            return bookwithPublishers;


        }
        

        public IList<Book> GetWithCriteria(Func<Book, bool> criteria)
        {
            return db.Books.Where(criteria).ToList();
        }

        public Book Update(Book entity)
        {
            db.Entry(entity).State = Microsoft.EntityFrameworkCore.EntityState.Modified;

            db.SaveChanges();

            return entity;
        }

        Book IRepos<Book>.GetById(int id)
        {
            throw new NotImplementedException();
        }
    }
}
