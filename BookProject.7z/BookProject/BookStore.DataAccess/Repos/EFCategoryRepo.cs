﻿using BookStore.DataAccess.data;
using BookStore.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore.DataAccess.Repos
{
    public class EFCategoryRepo : ICategoryRepo
    {

        private BookDbContext db;

        public EFCategoryRepo(BookDbContext bookDbContext)

        {

            db = bookDbContext;

        }

        public Category Add(Category entity)
        {
            db.Categories.Add(entity);

            db.SaveChanges();

            return entity;
        }

        public void Delete(int id)
        {
            db.Categories.Remove(GetById(id));
            db.SaveChanges();
        }

        public IList<Category> GetAll()
        {
            return db.Categories.ToList();
        }

        public Category GetById(int id)
        {
            return db.Categories.AsNoTracking().FirstOrDefault(x => x.Id == id);
        }

        public IList<Category> GetWithCriteria(Func<Category, bool> criteria)
        {
            return db.Categories.Where(criteria).ToList();
        }

        public Category Update(Category entity)
        {
            db.Entry(entity).State = Microsoft.EntityFrameworkCore.EntityState.Modified;

            db.SaveChanges();

            return entity;
        }

        public Category GetBooksInCategory ( ) 
        {
            throw new NotImplementedException();

        }
       

    }
}
