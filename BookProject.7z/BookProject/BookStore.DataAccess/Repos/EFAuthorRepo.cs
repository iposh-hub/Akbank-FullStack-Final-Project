﻿using BookStore.DataAccess.data;
using BookStore.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore.DataAccess.Repos
{
    public class EFAuthorRepo : IAuthorRepo
    {

        private BookDbContext db;

        public EFAuthorRepo(BookDbContext bookDbContext)

        {

            db = bookDbContext;

        }

        public Author Add(Author entity)
        {
            db.Authors.Add(entity);

            db.SaveChanges();

            return entity;
        }

        public void Delete(int id)
        {
            db.Authors.Remove(GetById(id));
            db.SaveChanges();
        }

        public IList<Author> GetAll()
        {
            return db.Authors.ToList();
        }

        public Author GetById(int id)
        {
            return db.Authors.AsNoTracking().FirstOrDefault(x => x.Id == id);
        }

        public IList<Author> GetWithCriteria(Func<Author, bool> criteria)
        {
            return db.Authors.Where(criteria).ToList();
        }

        public Author Update(Author entity)
        {
            db.Entry(entity).State = Microsoft.EntityFrameworkCore.EntityState.Modified;

            db.SaveChanges();

            return entity;
        }

        public IList<Book> GetAllBooksOfAuthor(int authorId) 
        {
            throw new NotImplementedException();

        }

       

    }
}
