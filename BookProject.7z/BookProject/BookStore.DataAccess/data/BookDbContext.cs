﻿using BookStore.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore.DataAccess.data
{
    public class BookDbContext: DbContext
    {
        public DbSet<Book> Books { get; set; }

        public DbSet<Category> Categories { get; set; }

        public DbSet<Author> Authors { get; set; }

        public DbSet<Publisher> Publishers { get; set; }

        public DbSet<Book_Publisher> Book_Publishers { get; set; }

        public BookDbContext()
        {

        }


        public BookDbContext(DbContextOptions<BookDbContext> options) : base(options)
        {

            //startupptan veri tabanını al ve burada kullan 

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            //relationship is defined btw category&book tables (OneToMany) 

            modelBuilder.Entity<Book>()

                        .HasOne(b => b.Category)

                        .WithMany(c => c.Books)

                        .HasForeignKey(b => b.CategoryId)

                        .OnDelete(DeleteBehavior.NoAction);

            //relationship btw author & book will be defined (OneToMany) 

            modelBuilder.Entity<Book>()

                        .HasOne(b => b.Author)

                        .WithMany(a => a.Books)

                        .HasForeignKey(b => b.AuthorId)

                        .OnDelete(DeleteBehavior.NoAction);

            //relationship btw book& publisher was defined (ManyToMany) 



            modelBuilder.Entity<Book_Publisher>()

                        .HasKey(bp => new { bp.BookId, bp.PublisherId });


            modelBuilder.Entity<Book_Publisher>()

                        .HasOne(bp => bp.Book)

                        .WithMany(book => book.Publishers)

                        .HasForeignKey(bp => bp.PublisherId);

            modelBuilder.Entity<Book_Publisher>()

                        .HasOne(bp => bp.Publisher)

                        .WithMany(publisher => publisher.Books)

                        .HasForeignKey(bp => bp.BookId);



            base.OnModelCreating(modelBuilder);





        }



    }

} 
    

