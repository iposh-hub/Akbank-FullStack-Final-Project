﻿ using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore.Models
{
    public class Book : IEntity
    {
        [Required(ErrorMessage = "Kitap ismi boş olamaz!")]
        public string Name { get; set ; }
        public int Id { get ; set ; }
        public string Language { get; set; }

        public int NumberOfPages { get; set; }

        public string AboutBook { get; set; }

        public DateTime PublishDate { get; set; }

        public decimal Price { get; set; }
        public decimal? Discount { get; set; }
        public float? DiscountedPrice { get; set; }
        public string PosterPath { get; set; }

        public int CategoryId { get; set; }

        public int AuthorId { get; set; }



        //Navigation Property  

        public virtual Category Category { get; set; }

        public virtual Author Author { get; set; }

        public virtual IList<Book_Publisher> Publishers { get; set; }



       
    }
}
