﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore.Models
{
    public class Publisher : IEntity
    {
        [Required(ErrorMessage = "Film adı boş olamaz!")]
        public string Name { get; set; }
        public int Id { get ; set; }
        public virtual IList<Book_Publisher> Books { get; set; }
    }
}
