﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore.Models
{
    public class BookWithPublishers
    {
        public string Name { get; set; }
        public int Id { get; set; }
        public string Language { get; set; }

        public int NumberOfPages { get; set; }

        public string AboutBook { get; set; }

        public DateTime PublishDate { get; set; }

        public decimal Price { get; set; }
        public decimal? Discount { get; set; }
        public float? DiscountedPrice { get; set; }
        public string PosterPath { get; set; }

        public string CategorName { get; set; }

        public string AuthorName { get; set; }

        public List<string> PublisherNames { get; set; }
    }
}
