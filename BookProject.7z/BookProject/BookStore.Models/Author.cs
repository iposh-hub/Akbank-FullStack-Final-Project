﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore.Models
{
    public class Author : IEntity
    {
        public string Name { get ; set ; }
        public int Id { get ; set ; }
        public string AboutTheAuthor { get; set; }

        public string AuthorPoster { get; set; }

        public virtual IList<Book> Books { get; set; }
    }
}
