﻿using Bookstore.Business;
using Bookstore.Business.DataTransferObjects;
using BookStore.API.Filters;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStore.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private ICategoryService service;
        public CategoryController(ICategoryService categoryService)
        {
            service = categoryService;
        }

        [HttpGet("get-all-categories")]

        public IActionResult GetAllBooks()
        {
            var allCategories = service.GetAllGCategories(); ;
            return Ok(allCategories);

        }

        [HttpGet("get-category-by-id/{id:int}")]

        public IActionResult GetCategoryById(int id)
        {
            var categorySearched = service.GetCategoriesById(id);
            if (categorySearched != null)
            {
                return Ok(categorySearched);
            }
            return NotFound();


        }

        [HttpPost("add-category")]
        public IActionResult AddBook(AddNewCategoryRequest request)
        {
            if (ModelState.IsValid)
            {
                int categoryId = service.AddGCategory(request);
                return CreatedAtAction(nameof(GetCategoryById), routeValues: new { id = categoryId }, value: null);
            }
            return BadRequest(ModelState);

        }

        [HttpPut("update-category/{id:int}")]
        [IsCategoryExist]
        public IActionResult UpdateBook(int id, EditCategoryRequest request)
        {
            if (ModelState.IsValid)
            {
                int newItemId = service.UpdateCategory(request);
                return Ok();
            }
            return BadRequest(ModelState);
        }


        [HttpDelete("delete-category/{id}")]
        [IsCategoryExist]
        public IActionResult Delete(int id)
        {
            service.DeleteCategory(id);
            return Ok();

        }

        [HttpGet("get-books-in-the category/{id}")]
        [IsCategoryExist]
        public IActionResult GetBooksInTheCategory (int id) 
        {
            return Ok();
        }
    }
}
