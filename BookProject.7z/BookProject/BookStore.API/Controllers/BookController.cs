﻿using Bookstore.Business;
using Bookstore.Business.DataTransferObjects;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BookStore.API.Filters;
using Microsoft.AspNetCore.Authorization;

namespace BookStore.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class BookController : ControllerBase
    {
        private IBookService bookService;

        public BookController(IBookService service) 
        {
            bookService = service;
        }

        
        [HttpGet("get-all-books")]
        [AllowAnonymous]

        public IActionResult GetAllBooks() 
        {
            var allBooks = bookService.GetAllBooks();
            return Ok(allBooks);
        
        }

        [HttpGet("get-book-by-id/{id:int}")]
        [AllowAnonymous]

        public IActionResult GetBookById(int id) 
        {
            var bookSearched = bookService.GetById(id);
            if (bookSearched != null) 
            {
                return Ok(bookSearched);
            }
            return NotFound();
            
        
        }

        [HttpGet("get-book-byNameOr-author/{term:string}")]
        [AllowAnonymous]
        public IActionResult GetBookByCriteria(string term) 
        {
            var bookSearched = bookService.GetBookByCriteria(term);
            if (bookSearched !=null) 
            {
                return Ok(bookSearched);

            }
            return NotFound();
        }
        
        [HttpPost("add-book")]
        [Authorize(Roles = "Admin,Editor")]
        public IActionResult AddBook(AddNewBookRequest request) 
        {
            if (ModelState.IsValid) 
            {
                int bookId = bookService.AddBook(request);
                return CreatedAtAction(nameof(GetBookById), routeValues: new {id= bookId }, value: null);
            }
            return BadRequest(ModelState);
        
        }

        [HttpPut("update-book/{id:int}")]
        [IsBookExist]
        [Authorize(Roles = "Admin,Editor")]
        public IActionResult UpdateBook(int id, EditBooksRequest request)
        {
            if (ModelState.IsValid) 
            {
                int newItemId = bookService.UpdateBook(request);
                return Ok(newItemId);
            }
            return BadRequest(ModelState);
        }


        [HttpDelete("delete-book/{id}")]
        [IsBookExist]
        [Authorize(Roles = "Admin,Editor")]
        public IActionResult Delete(int id) 
        {
            bookService.DeleteBook(id);
            return Ok();
        
        }
    }
}
