﻿using Bookstore.Business;
using Bookstore.Business.DataTransferObjects;
using BookStore.API.Filters;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStore.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PublisherController : ControllerBase
    {
        private IPublisherService service;
        public PublisherController(IPublisherService publisherService)
        {
            this.service = publisherService;
        }


        [HttpGet("get-all-publishers")]

        public IActionResult GetAllBooks()
        {
            var allPublishers = service.GetAllPublishers(); 
            return Ok(allPublishers);

        }

        [HttpGet("get-publisher-by-id/{id:int}")]

        public IActionResult GetPublisherById(int id)
        {
            var categorySearched = service.GetPublishersById(id);
            if (categorySearched != null)
            {
                return Ok(categorySearched);
            }
            return NotFound();


        }

        [HttpPost("add-publisher")]
        public IActionResult AddBook(AddNewPublisherRequest request)
        {
            if (ModelState.IsValid)
            {
                int publisherId = service.AddPublisher(request);
                return CreatedAtAction(nameof(GetPublisherById), routeValues: new { id = publisherId }, value: null);
            }
            return BadRequest(ModelState);

        }

        [HttpPut("update-publisher/{id:int}")]
        [IsPublisherExist]
        public IActionResult UpdateBook(int id, EditPublisherRequest request)
        {
            if (ModelState.IsValid)
            {
                int newItemId = service.UpdatePublisher(request);
                return Ok();
            }
            return BadRequest(ModelState);
        }


        [HttpDelete("delete-publisher/{id}")]
        [IsPublisherExist]
        public IActionResult Delete(int id)
        {
            service.DeletePublisher(id);
            return Ok();

        }

        [HttpGet("get-books-ofThe-publisher/{id}")]
        [IsPublisherExist]
        public IActionResult GetBooksInTheCategory(int id)
        {
            return Ok();
        }

    }
}
