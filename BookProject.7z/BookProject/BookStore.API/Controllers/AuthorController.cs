﻿using Bookstore.Business;
using Bookstore.Business.DataTransferObjects;
using BookStore.API.Filters;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStore.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthorController : ControllerBase
    {
        private IAuthorService service;
        public AuthorController(IAuthorService authorService)
        {
            this.service = authorService;
        }

        [HttpGet("get-all-authors")]

        public IActionResult GetAllAuthors()
        {
            var allAuthors = service.GetAllAuthors();
            return Ok(allAuthors);

        }

        [HttpGet("get-author-by-id/{id:int}")]

        public IActionResult GetAuthorById(int id)
        {
            var authorSearched = service.GetAuthorsById(id);
            if (authorSearched != null)
            {
                return Ok(authorSearched);
            }
            return NotFound();


        }

        [HttpPost("add-author")]
        public IActionResult AddBook(AddNewAuthorRequest request)
        {
            if (ModelState.IsValid)
            {
                int authorId = service.AddAuthor(request);
                return CreatedAtAction(nameof(GetAuthorById), routeValues: new { id = authorId }, value: null);
            }
            return BadRequest(ModelState);

        }

        [HttpPut("update-author/{id:int}")]
        [IsAuthorExist]
        public IActionResult UpdateBook(int id, EditAuthorRequest request)
        {
            if (ModelState.IsValid)
            {
                int newItemId = service.UpdateAuthor(request);
                return Ok();
            }
            return BadRequest(ModelState);
        }


        [HttpDelete("delete-publisher/{id}")]
        [IsAuthorExist]
        public IActionResult Delete(int id)
        {
            service.DeleteAuthor(id);
            return Ok();

        }

        [HttpGet("get-books-ofThe-author/{id}")]
        [IsAuthorExist]
        public IActionResult GetBooksOfTheAuthor(int id)
        {
            return Ok();
        }
    }
}
