using Bookstore.Business;
using Bookstore.Business.Extensions;
using BookStore.DataAccess.data;
using BookStore.DataAccess.Repos;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore.API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddControllers();
            services.AddMapperConfiguration();
            services.AddScoped<IBookService, BookService>();
            services.AddScoped<IBookRepo, EFBookRepo>();
            services.AddScoped<IAuthorService, AuthorService>();
            services.AddScoped<IAuthorRepo, EFAuthorRepo>();
            services.AddScoped<ICategoryService, CategoryService>();
            services.AddScoped<ICategoryRepo, EFCategoryRepo>();
            services.AddScoped<IPublisherService, PublisherService>();
            services.AddScoped<IPublisherRepo, EFPublisherRepo>();

            services.AddScoped<IUser, UserService>();
            services.AddScoped<IUserRepo, UserRepo>();
            var connectionString = Configuration.GetConnectionString("db");
            services.AddDbContext<BookDbContext>(option => option.UseSqlServer(connectionString));
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "BookStore.API", Version = "v1" });
            });
            var issuer = Configuration.GetSection("Bearer")["Issuer"];
            var audience = Configuration.GetSection("Bearer")["Audience"];
            var key = Configuration.GetSection("Bearer")["SecurityKey"];

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                   .AddJwtBearer(opt =>
                   {
                       opt.TokenValidationParameters = new TokenValidationParameters()
                       {
                           ValidateActor = true,
                           ValidateAudience = true,
                           ValidateIssuer = true,
                           ValidateIssuerSigningKey = true,
                           ValidIssuer = issuer,
                           ValidAudience = audience,
                           IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key))
                       };
                   });

            services.AddCors(opt =>
            {
                opt.AddPolicy("Allow", builder =>
                {
                    builder.AllowAnyOrigin()
                           .AllowAnyMethod()
                           .AllowAnyHeader();
                });

            });


        }
        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "BookStore.API v1"));
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthentication();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
