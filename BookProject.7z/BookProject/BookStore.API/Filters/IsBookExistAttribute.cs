﻿using Bookstore.Business;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStore.API.Filters
{
    public class IsBookExistAttribute : TypeFilterAttribute
    {
        public IsBookExistAttribute() : base(typeof(BookExistingFilter))
        {

        }


        private class BookExistingFilter : IAsyncActionFilter
        {

            private IBookService bookService;
            public BookExistingFilter (IBookService bookService) 
            {
                this.bookService = bookService;
            }
            public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
            {
                if (!context.ActionArguments.ContainsKey("id"))
                {
                    context.Result = new BadRequestResult();
                    return;
                }

                if (!(context.ActionArguments["id"] is int id))
                {
                    context.Result = new BadRequestResult();
                    return;
                }

                var book = bookService.GetById(id);
                if (book == null)
                {
                    context.Result = new NotFoundObjectResult(new { Message = $"{id} nolu kitap bulunamadı " });
                    return;
                }

                await next();
            }
        }




    }
}
