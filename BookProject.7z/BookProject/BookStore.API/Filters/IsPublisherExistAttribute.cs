﻿using Bookstore.Business;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStore.API.Filters
{
    public class IsPublisherExistAttribute: TypeFilterAttribute
    {
        public IsPublisherExistAttribute() : base(typeof(PublisherExistingFilter))
        {

        }


        private class PublisherExistingFilter : IAsyncActionFilter
        {

            private IPublisherService puublisherService;
            public PublisherExistingFilter(IPublisherService puublisherService)
            {
                this.puublisherService = puublisherService;
            }
            public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
            {
                if (!context.ActionArguments.ContainsKey("id"))
                {
                    context.Result = new BadRequestResult();
                    return;
                }

                if (!(context.ActionArguments["id"] is int id))
                {
                    context.Result = new BadRequestResult();
                    return;
                }

                var publisher = puublisherService.GetPublishersById(id);
                if (publisher == null)
                {
                    context.Result = new NotFoundObjectResult(new { Message = $"{id} nolu yayımcı bulunamadı " });
                    return;
                }

                await next();
            }
        }
    }
}
