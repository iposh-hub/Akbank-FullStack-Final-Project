﻿using BookStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore.ViewModels
{
    public class BookVM:IEntity
    {
        public string Name { get; set; }
        public int Id { get; set; }
        public string AboutBook { get; set; }
        public decimal Price { get; set; }
        public decimal? Discount { get; set; }
        public float? DiscountedPrice { get; set; }
        public string PosterPath { get; set; }
        public int CategoryId { get; set; }
        public int AuthorId { get; set; }
        public List<int> PublisherIds { get; set; }

    }
}
